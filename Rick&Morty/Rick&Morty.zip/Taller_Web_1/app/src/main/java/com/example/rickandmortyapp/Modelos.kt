package com.example.rickandmortyapp

import kotlinx.serialization.Serializable

// 1. Respuesta principal de la API
@Serializable
data class RespuestaApi(
    val info: Info,
    val results: List<Personaje>
)

// 2. Información de paginación que da la API
@Serializable
data class Info(
    val count: Int,
    val pages: Int,
    val next: String?,
    val prev: String?
)

// 3. El Personaje con todos los campos necesarios para el 5.0
@Serializable
data class Personaje(
    val id: Int,
    val name: String,
    val status: String,
    val species: String,
    val gender: String,
    val image: String,
    val origin: NameUrl,
    val location: NameUrl
)

// 4. Estructura para nombres y links (Origin y Location)
@Serializable
data class NameUrl(
    val name: String,
    val url: String
)

// --- LÓGICA PARA EL SELECTOR DE LIBRERÍAS (NUEVO) ---

data class PaginaRick(
    val numero: Int,
    val rango: String
)

// Función que genera las páginas dinámicamente
fun generarListaPaginas(): List<PaginaRick> {
    val lista = mutableListOf<PaginaRick>()
    // La API tiene 42 páginas. Cada página tiene 20 personajes.
    for (i in 1..42) {
        val inicio = (i - 1) * 20 + 1
        val fin = i * 20
        lista.add(PaginaRick(i, "Personajes $inicio - $fin"))
    }
    return lista
}